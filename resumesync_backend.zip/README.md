# ResumeSync AI Backend

Flask-based backend to customize resumes and generate cover letters using OpenAI.

## Endpoints
- POST /customize-resume
- POST /generate-cover-letter

## Setup
1. Add your OpenAI key to `.env`
2. Run `pip install -r requirements.txt`
3. Start the app with `python app.py`