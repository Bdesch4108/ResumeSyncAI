import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import openai

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

app = Flask(__name__)
CORS(app)

@app.route("/customize-resume", methods=["POST"])
def customize_resume():
    data = request.get_json()
    job_description = data.get("job_description")
    user_resume = data.get("user_resume")

    if not job_description or not user_resume:
        return jsonify({"error": "Missing required fields."}), 400

    prompt = f"""
You are an expert resume editor. Your job is to customize a resume based on a job description.

Step 1: Read the job description and extract relevant keywords, skills, and responsibilities.
Step 2: Read the user's resume and identify matching experience, skills, or accomplishments.
Step 3: Rewrite the resume bullet points using the language and tone from the job description. Prioritize clarity, measurable outcomes, and ATS-friendly phrasing.

DO NOT fabricate experience. Highlight what the candidate already has, using tailored language.

Return the updated resume in clean bullet format.

[Job Description]
{job_description}

[Resume]
{user_resume}
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a professional resume writer and editor."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1200
        )
        return jsonify({"customized_resume": response['choices'][0]['message']['content']}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/generate-cover-letter", methods=["POST"])
def generate_cover_letter():
    data = request.get_json()
    job_description = data.get("job_description")
    user_resume = data.get("user_resume")

    if not job_description or not user_resume:
        return jsonify({"error": "Missing required fields."}), 400

    prompt = f"""
You are a professional career writer. Write a personalized, concise, and compelling cover letter tailored to the job description and resume below.

Keep it under 200 words. Focus on alignment between the candidate's experience and the role requirements. Use a confident, professional tone.

[Job Description]
{job_description}

[Resume]
{user_resume}
    """

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a professional cover letter writer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=600
        )
        return jsonify({"cover_letter": response['choices'][0]['message']['content']}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
